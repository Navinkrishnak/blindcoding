#!/bin/bash
cd ~
cd /home/talos/system/systemfiles
python3 /home/talos/system/systemfiles/first.py
cd