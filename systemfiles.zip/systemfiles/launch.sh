#!/bin/bash
gnome-terminal -- bash -c "/home/talos/system/systemfiles/app.sh; exec bash"
